﻿<?php
include 'assets/templates/head.php';
include 'assets/templates/nav.php';
include 'assets/templates/inicio.php';

?>