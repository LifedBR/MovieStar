<div class="container">
<nav aria-label="breadcrumb" style="margin-top: 50px;">
<div class="circulo"><div class="pag_left"></div></div>
<div class="circulo"><div class="pag_right"></div></div>

<ol class="breadcrumb d-flex flex-column">
<h1 class="titulo-site">New Movies</h1>
<h6>Lorem Ipsum is simply dummy text of the printing and typesetting.</h6>
</ol>
</nav>


</div>