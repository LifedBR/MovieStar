<nav class="navbar navbar-light bg-new d-flex justify-content-between">
<div class="container">
	<li class="navlogin"><i class="fa fa-user-circle-o" aria-hidden="true"></i> Registro &nbsp;&nbsp;&nbsp;<span><i class="fa fa-lock"></i> Login</span></li>
	<li class="navlogin"> <i class="fa fa-envelope-o" aria-hidden="true"></i> Superhit Top Movie <span>** King Star **</span></li>
	<li class="navlogin"><i class="fa fa-users" aria-hidden="true"></i> Day Visitor 32155</li>

</div>
</nav>

<nav class="navbar navbar-light bg-new">
<div class="container">
<a class="navbar-brand" href="#">
    <img src="/assets/imagens/logo.png" alt="Movie Star"/>
  </a>

<form class="form-inline">
    <input class="form-control mr-sm-2" type="search" placeholder="Procurar..." aria-label="Search">
    <button class="btn procurar my-2 my-sm-0" type="submit">Procurar</button>
  </form>
</div>
</nav>

<nav class="navbar navbar-expand-lg navbar-light bg-new">
<div class="container">

  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Movie Layout</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Celebrities</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Showtime</a>
      </li>
		<li class="nav-item">
        <a class="nav-link" href="#">News</a>
      </li>
		<li class="nav-item">
        <a class="nav-link" href="#">Contacts</a>
      </li>
    </ul>
  </div>
<div class="d-flex flex-row-reverse" style="color: #FFF;">
<i class="fa fa-instagram p-1 bd-highlight" aria-hidden="true"></i>
<i class="fa fa-youtube-play p-1 bd-highlight" aria-hidden="true"></i>
<i class="fa fa-twitter-square p-1 bd-highlight" aria-hidden="true"></i>
<i class="fa fa-skype p-1 bd-highlight" aria-hidden="true"></i>
<i class="fa fa-facebook p-1 bd-highlight" aria-hidden="true"></i>
</div>
</div>
</nav>

