<div class="container">
<nav aria-label="breadcrumb" style="margin-top: 50px;">
<div class="circulo"><div class="pag_left"></div></div>
<div class="circulo"><div class="pag_right"></div></div>

<ol class="breadcrumb d-flex flex-column">
<h1 class="titulo-site">Movies Category</h1>
<h6>Lorem Ipsum is simply dummy text of the rinting and typesetting.</h6>
</ol>
</nav>

  <div class="row justify-content-center">
    <div class="grid_box">
		<div class="sombra"></div>
		<div class="hora">02:50:12</div>
		<div class="star"><span><i class="fa fa-star-o" aria-hidden="true"></i></span> 5/9</div>
		<div class="play d-flex justify-content-center"></div>
		<h6>Hurry Animate Blue Strack New Movie (2018)</h6>
		<h5>Category: Hot Movies</h5>
	</div>
	
	<div class="grid_box">
		<div class="sombra"></div>
		<div class="hora">02:50:12</div>
		<div class="star"><span><i class="fa fa-star-o" aria-hidden="true"></i></span> 5/9</div>
		<div class="play d-flex justify-content-center"></div>
		<h6>Hurry Animate Blue Strack New Movie (2018)</h6>
		<h5>Category: Hot Movies</h5>
	</div>
	
	<div class="grid_box">
		<div class="sombra"></div>
		<div class="hora">02:50:12</div>
		<div class="star"><span><i class="fa fa-star-o" aria-hidden="true"></i></span> 5/9</div>
		<div class="play d-flex justify-content-center"></div>
		<h6>Hurry Animate Blue Strack New Movie (2018)</h6>
		<h5>Category: Hot Movies</h5>
	</div>
  </div>

</div>

