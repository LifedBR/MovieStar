<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">

    <div class="carousel-item active">
      <img class="d-block w-100" src="/assets/imagens/slide.png" alt="First slide">
  <div class="carousel-caption d-none d-md-block ">
<h5>Welcome to Our movie site</h5>
<h1>Filmes Online <span>Movies</span></h1>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industrioy. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>
<button type="button" class="btn btn-read">Read More</button>
</div>
  </div>
  
<div class="carousel-item">
      <img class="d-block w-100" src="/assets/imagens/slide.png" alt="First slide">
  <div class="carousel-caption d-none d-md-block ">
<h5>Welcome to Our movie site</h5>
<h1>Our special <span>Movies</span></h1>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industrioy. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>
<button type="button" class="btn btn-read">Read More</button>
</div>
  </div>

  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
<div class="seta-slide-right"></div>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <div class="seta-slide-left"></div>
    <span class="sr-only">Next</span>
  </a>
</div>

<?php include 'movie_categoria.php'; ?>
<?php include 'new_movie.php'; ?>

